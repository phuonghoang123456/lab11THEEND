package com.example.bai7_allurejacoco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bai7Application {
    public static void main(String[] args) {
        SpringApplication.run(Bai7Application.class, args);
    }
}
